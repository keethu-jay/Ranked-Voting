
/**
 *  Exception class to handle cases where a nominee has already been nominated.
 */
 public class AlreadyNominatedException extends Exception{
    /**
     * Constructs an AlreadyNominatedException with a specific message indicating the nominee has already been nominated.
     *
     * @param nomineeName The name of the nominee who has already been nominated.
     */
    public AlreadyNominatedException (String winner) {
        // Call the constructor of the parent class (Exception) and pass a formatted message.
        super (winner + " has already been nominated.");
    }
}
