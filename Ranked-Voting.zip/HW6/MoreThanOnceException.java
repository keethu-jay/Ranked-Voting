/**
 * Custom exception class to handle cases where a candidate was voted for multiple times.
 */
public class MoreThanOnceException extends Exception {

    /**
     * Constructs a MoreThanOnceException with a specific message indicating a candidate was voted for multiple times.
     *
     * @param candidateSeveralNominations The name of the candidate who received multiple votes.
     */
    public MoreThanOnceException (String candidateSeveralNominations) {
        // Call the constructor of the parent class (Exception) and pass a formatted message.
        super(candidateSeveralNominations+" was voted for multiple times.");
    }
}
