import java.util.Scanner;

/**
 * Simulates a simple voting machine that interacts with an ElectionData object.
 */
public class VotingMachine {
    ElectionData eData;
    /**
     * Initializes the VotingMachine with an ElectionData object using the MostFirstVotesStrategy.
     */
    public VotingMachine() {
        eData = new ElectionData(new MostFirstVotesStrategy());
    }

    /**
     * Main method to simulate the voting machine's functionality.
     *
     * @param args Command-line arguments (not used in this context).
     */
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        VotingMachine vm = new VotingMachine();
        boolean run = true;
        // Main loop to run the voting machine
        while (run) {
            System.out.println("Current candidates are: " + vm.eData.getCandidates());
            System.out.println("Do you want to [n]ominate someone, [v]ote for someone, change winner\n" +
                    "[s]trategy, see who [w]on, or [q]uit?");
            String input = keyboard.nextLine();
            // Process user input
            switch (input.charAt(0)) {
                case 'n':
                    System.out.println("Who do you want to nominate?");
                    String nomination = keyboard.nextLine();
                    try {
                        vm.eData.nominateCandidate(nomination);
                    } catch (AlreadyNominatedException ane) {
                        System.out.println(ane);
                    }
                    break;
                case 'v':
                    System.out.println("Who is your first choice?");
                    String firstVote = keyboard.nextLine();
                    System.out.println("Who is your second choice?");
                    String secondVote = keyboard.nextLine();
                    System.out.println("Who is your third choice?");
                    String thirdVote = keyboard.nextLine();
                    try {
                        vm.eData.submitVote(firstVote, secondVote, thirdVote);
                    } catch (CandidateNotNominatedException cnne){
                        System.out.println(cnne);
                    } catch (MoreThanOnceException mtoe){
                        System.out.println(mtoe);
                    }
                    break;
                case 's':
                    boolean askStrats = true;
                    while(askStrats) {
                        System.out.println("Which strategy would you like to use? most [f]irst votes or most [a]greeable?");
                        String strat = keyboard.nextLine();
                        switch (strat.charAt(0)) {
                            case 'f':
                                askStrats = false;
                                vm.eData.setStrategy(new MostFirstVotesStrategy());
                                break;
                            case 'a':
                                askStrats = false;
                                vm.eData.setStrategy(new MostAgreeableStrategy());
                                break;
                            default:
                                System.out.println("You seem to have made a misinput. Please try again.");
                                break;
                        }
                    }
                    break;
                case 'w':
                    System.out.println("The winner is: "+vm.eData.calculateWinner());
                    break;
                case 'q':
                    run = false;
                    break;
                default:
                    break;

            }
        }
    }

}
