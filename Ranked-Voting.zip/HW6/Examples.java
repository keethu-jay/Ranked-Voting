import org.junit.Test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class Examples {
    ElectionData eData;

    public Examples() {
        eData = new ElectionData(new MostFirstVotesStrategy());
    }

    @Test
    public void testOneVote() {
        try {
            this.eData.nominateCandidate("gompei");
            this.eData.nominateCandidate("husky");
            this.eData.nominateCandidate("bristaco");
            this.eData.submitVote("gompei", "husky", "bristaco");
        } catch (Exception e) {
            fail(e.getMessage());
        }
         assertEquals(Optional.of("gompei"), this.eData.calculateWinner());
    }
    @Test //(expected = CandidateNotNominatedException.class)
    public void testnoVotesCast() {
        try {
            //this.eData.submitVote("", "husky", "bristaco");
            this.eData.calculateWinner();
        } catch (Exception e) {
            fail(e.getMessage());
        }
        assertEquals(Optional.empty(), this.eData.calculateWinner());
    }
    @Test
    public void MostFirstVotesStrategyComplicated() {
        try {
            this.eData.nominateCandidate("gompei");
            this.eData.nominateCandidate("husky");
            this.eData.nominateCandidate("bristaco");
            this.eData.submitVote("gompei", "husky", "bristaco");
            this.eData.submitVote("bristaco", "gompei", "husky");
            this.eData.submitVote("husky", "bristaco", "gompei");
        } catch (Exception e) {
            fail(e.getMessage());
        }
        Set<String> ret = new HashSet<>();
        ret.add("bristaco");
        ret.add("husky");
        ret.add("gompei");
        assertEquals(ret,this.eData.getCandidates());
        assertEquals(Optional.empty(), this.eData.calculateWinner());
    }
    @Test(expected = MoreThanOnceException.class)
    public void votedTwiceTest() throws MoreThanOnceException{
        try {
            this.eData.nominateCandidate("gompei");
            this.eData.nominateCandidate("husky");
            this.eData.nominateCandidate("bristaco");
            this.eData.submitVote("gompei", "gompei", "bristaco");
        } catch (AlreadyNominatedException e) {
            fail("asddd");
        }catch (CandidateNotNominatedException a) {
            fail("asd");
        }
        fail("aa");
    }
    @Test
    public void getCandidateMutableError () {
        Set<String> cand = this.eData.getCandidates();
        try  {
            cand.add("Obama");
        } catch (Exception e) {
            fail("WhoopsieDoopsie");
        }
        assertEquals("No change", 0, eData.getCandidates().size());

    }
    @Test
    public void MostAgreeableStrategy() {
        eData.setStrategy(new MostAgreeableStrategy());
        try {
            this.eData.nominateCandidate("gompei");
            this.eData.nominateCandidate("husky");
            this.eData.nominateCandidate("bristaco");
            this.eData.submitVote("gompei", "husky", "bristaco");
        } catch (Exception e) {
            fail(e.getMessage());
        }
        assertEquals(Optional.empty(), this.eData.calculateWinner());
    }
    @Test(expected = CandidateNotNominatedException.class)
    public void submitWrongVoteTest() throws CandidateNotNominatedException{
        try {
            this.eData.nominateCandidate("gompei");
            this.eData.nominateCandidate("husky");
            this.eData.nominateCandidate("bristaco");
            this.eData.submitVote("pee", "husky", "bristaco");
        } catch (AlreadyNominatedException e) {
            fail("t");
        } catch (MoreThanOnceException a) {
            fail("p");
        }
        fail("pee not nominated");
    }

    @Test(expected = AlreadyNominatedException.class)
    public void testCandidateAlreadyNominated() throws AlreadyNominatedException {
        this.eData.nominateCandidate("gompei");
        this.eData.nominateCandidate("gompei");
    }
}