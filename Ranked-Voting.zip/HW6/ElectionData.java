import java.util.*;

/**
 * Manages the data and operations related to an election.
 */
public class ElectionData {
    private HashMap<String, Votes> eData; // Stores candidate votes
    private I3VoteStrategy strategy;  // Strategy for calculating the winner

    /**
     * Constructs an ElectionData object with a specified voting strategy.
     *
     * @param strategy The voting strategy to be used for calculating the winner.
     */
    public ElectionData(I3VoteStrategy strategy) {
        this.strategy = strategy;
        this.eData = new HashMap<>();
    }

    /**
     * Sets a new voting strategy.
     *
     * @param strategy The new voting strategy to be set.
     */
    public void setStrategy(I3VoteStrategy strategy) {
        this.strategy = strategy;
    }

     /**
     * Retrieves the set of candidates.
     *
     * @return A Set containing the names of all nominated candidates.
     */
    public Set<String> getCandidates() {
        Set<String> candidates = new HashSet<>();
        for (HashMap.Entry<String, Votes> votes : this.eData.entrySet()) {
            candidates.add(votes.getKey());
        }
        return candidates;
    }

    /**
     * Nominates a candidate for the election.
     *
     * @param person The name of the candidate to be nominated.
     * @throws AlreadyNominatedException If the candidate has already been nominated.
     */
    public void nominateCandidate(String person) throws AlreadyNominatedException {
        if (!this.eData.containsKey(person)) {
            this.eData.put(person, new Votes(0,0,0));
        } else {
            throw new AlreadyNominatedException(person);
        }
    }

    /**
     * Submits a vote for the election, considering first, second, and third preferences.
     *
     * @param first  The candidate receiving the first preference vote.
     * @param second The candidate receiving the second preference vote.
     * @param third  The candidate receiving the third preference vote.
     * @throws CandidateNotNominatedException If any of the candidates haven't been nominated.
     * @throws MoreThanOnceException         If a candidate is selected more than once.
     */
    public void submitVote(String first, String second, String third) throws CandidateNotNominatedException, MoreThanOnceException {
        if (first.equals(second) || first.equals(third))
            throw new MoreThanOnceException(first);
        if (second.equals(third))
            throw new MoreThanOnceException(second);
        if (!this.eData.containsKey(first))
            throw new CandidateNotNominatedException(first);
        if (!this.eData.containsKey(second))
            throw new CandidateNotNominatedException(first);
        if (!this.eData.containsKey(third))
            throw new CandidateNotNominatedException(first);
        this.eData.get(first).voteFirst();
        this.eData.get(second).voteSecond();
        this.eData.get(third).voteThird();
    }

    /**
     * Calculates the winner of the election based on the current voting data and strategy.
     *
     * @return An Optional containing the name of the winning candidate (if any).
     */
    public Optional<String> calculateWinner() {
        HashMap<String, Votes> retEleData = new HashMap<>(this.eData);
        return this.strategy.calculateWinner(retEleData);
    }
}
