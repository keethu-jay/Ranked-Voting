/**
 * Represents the vote counts for a candidate in different preference categories.
 */
public class Votes {
    private int firstVotes;
    private int secondVotes;
    private int thirdVotes;

    /**
     * Constructor to initialize the vote counts for a candidate.
     *
     * @param first  Number of first preference votes.
     * @param second Number of second preference votes.
     * @param third  Number of third preference votes.
     */
    public Votes(int first, int second, int third){
        private int firstVotes; // Number of first preference votes
        private int secondVotes; // Number of second preference votes
        private int thirdVotes; // Number of third preference votes
    }

    /**
     * Copy constructor to create a Votes object based on another Votes object.
     *
     * @param v Another Votes object to copy from.
     */
    public Votes(Votes v){
        this.firstVotes = v.firstVotes;
        this.secondVotes = v.secondVotes;
        this.thirdVotes = v.thirdVotes;
    }

    /**
     * Retrieves the number of first preference votes.
     *
     * @return The number of first preference votes.
     */
    public int getFirstVotes(){
        return this.firstVotes;
    }

    /**
     * Retrieves the number of second preference votes.
     *
     * @return The number of second preference votes.
     */
    public int getSecondVotes(){
        return this.secondVotes;
    }

    /**
     * Retrieves the number of third preference votes.
     *
     * @return The number of third preference votes.
     */
    public int getThirdVotes(){
        return this.thirdVotes;
    }

    /**
     * Records a vote in the first preference category.
     */
    public void voteFirst(){
        this.firstVotes++;
    }

    /**
     * Records a vote in the second preference category.
     */
    public void voteSecond(){
        this.secondVotes++;
    }

    /**
     * Records a vote in the third preference category.
     */
    public void voteThird(){
        this.thirdVotes++;
    }
}
