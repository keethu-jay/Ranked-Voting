import java.util.HashMap;
import java.util.Optional;

/**
 * A voting strategy that determines the winner based on the candidate with the most agreeable votes.
 * This strategy considers the most agreeable candidate as the one with the most first, second, or third preference votes.
 */
public class MostAgreeableStrategy implements I3VoteStrategy{

    /**
     * Calculates the winner based on the provided voting data and the most agreeable votes.
     *
     * @param votes A HashMap containing the votes of candidates.
     *              Key: Candidate name; Value: Votes received by the candidate.
     * @return An Optional containing the name of the winning candidate (if any) based on the most agreeable votes.
     */
    @Override
    public Optional<String> calculateWinner(HashMap<String, Votes> votes) {
        if (votes.isEmpty())
            return Optional.empty();
        String currentWinner = null;
        int currentMostVotes = 0;
        Boolean equalVotes = false;
        // Iterate through the votes to determine the most agreeable candidate
        for (HashMap.Entry<String, Votes> entry : votes.entrySet()) {
            // Check first preference votes
            if (entry.getValue().getFirstVotes()>currentMostVotes) {
                currentMostVotes = entry.getValue().getFirstVotes();
                currentWinner = entry.getKey();
                equalVotes = false;
            }else if (entry.getValue().getFirstVotes()==currentMostVotes) {
                if (currentWinner != null) {
                    if (!currentWinner.equals(entry.getKey()))
                        equalVotes = true;
                }
            }

            // Check second preference votes
            if (entry.getValue().getSecondVotes()>currentMostVotes) {
                currentMostVotes = entry.getValue().getSecondVotes();
                currentWinner = entry.getKey();
                equalVotes = false;
            }else if (entry.getValue().getSecondVotes()==currentMostVotes) {
                if (currentWinner != null) {
                    if (!currentWinner.equals(entry.getKey()))
                        equalVotes = true;
                }
            }
            // Check third preference votes
            if (entry.getValue().getThirdVotes()>currentMostVotes) {
                currentMostVotes = entry.getValue().getThirdVotes();
                currentWinner = entry.getKey();
                equalVotes = false;
            } else if (entry.getValue().getThirdVotes()==currentMostVotes) {
                if (currentWinner != null) {
                    if (!currentWinner.equals(entry.getKey()))
                        equalVotes = true;
                }
            }
        }

        // If there are candidates with equal votes, return Optional.empty() indicating no clear winner
        if (equalVotes)
            return Optional.empty();

        // Return Optional containing the most agreeable candidate as the winner
        return Optional.of(currentWinner);
    }
}
