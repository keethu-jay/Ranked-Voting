/**
 * Custom exception class to handle cases where a candidate was not nominated.
 */
public class CandidateNotNominatedException extends Exception{
    private String candidateNotNominated; // Variable to store the candidate who was not nominated
     /**
     * Constructs a CandidateNotNominatedException with a specific message indicating the candidate was not nominated.
     *
     * @param candidate The name of the candidate who was not nominated.
     */
    public CandidateNotNominatedException (String candidate) {
        // Call the constructor of the parent class (Exception) and pass a formatted message.
        super (candidate + " was not nominated.");
        this.candidateNotNominated = candidate;
    }

    /**
     * Gets the name of the candidate who was not nominated.
     *
     * @return The name of the candidate who was not nominated.
     */
    public String getCandidate() {
        return this.candidateNotNominated; // Return the candidate name
    }
}
