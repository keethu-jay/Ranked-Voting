import java.util.HashMap;
import java.util.Optional;
/**
 * An interface for a modular "vote for 3 people" strategy.
 * Implementations of this interface calculate the winner based on voting data.
 */
public interface I3VoteStrategy {

     /**
     * Calculates the winner based on the provided voting data.
     *
     * @param votes A HashMap containing the votes of candidates.
     *              Key: Candidate name; Value: Votes received by the candidate.
     * @return An Optional containing the name of the winning candidate (if any).
     */
    Optional<String> calculateWinner(HashMap<String, Votes> votes);
}
