import java.util.HashMap;
import java.util.Optional;

/**
 * A voting strategy that determines the winner based on the candidate with the most first-preference votes.
 */
public class MostFirstVotesStrategy implements I3VoteStrategy{

    /**
     * Calculates the winner based on the provided voting data and the most first-preference votes.
     *
     * @param votes A HashMap containing the votes of candidates.
     *              Key: Candidate name; Value: Votes received by the candidate.
     * @return An Optional containing the name of the winning candidate (if any) based on the most first-preference votes.
     */
    @Override
    public Optional<String> calculateWinner(HashMap<String, Votes> votes) {
        if (votes.isEmpty())
            return Optional.empty();
        int totalVotes = 0;
        String currentWinner = null;

        // Iterate through the votes to determine the candidate with the most first-preference votes
        for (HashMap.Entry<String, Votes> entry : votes.entrySet()) {
            if (currentWinner != null) {
                if (entry.getValue().getFirstVotes() > votes.get(currentWinner).getFirstVotes())
                    currentWinner = entry.getKey();
            } else {
                currentWinner = entry.getKey();
            }
            totalVotes += entry.getValue().getFirstVotes();
        }
        // Check if the candidate with the most first-preference votes has more than half of the total votes
        if (votes.get(currentWinner).getFirstVotes()>(totalVotes/2))
            return Optional.of(currentWinner);
        else
            return Optional.empty();
    }
}
